#include <stdio.h>

int main()
{
	char inchar, inchar2;
	char outbuf[32768];
	char *outbptr;
	int i;
	int endcomment;
	int newline = 1;

	outbptr = outbuf;

	printf("paste in your score and then hit RETURN and type CTRL-Z and then CTRL-D followed by RETURN\n");

	do {
		inchar = getc(stdin);

		switch (inchar) {
			case '\n':
				if (newline == 1) break;

				sprintf(outbptr, " \" +\n\"");
				outbptr += 6;
				newline = 1;
				break;

			case '\r':
				if (newline == 1) break;

				sprintf(outbptr, " \" +\n\"");
				outbptr += 6;
				newline = 1;
				break;

			case '"':
				sprintf(outbptr, "\\\"");
				outbptr += 2;
				newline = 0;
				break;

			case '/':
				newline = 0;
				inchar = getc(stdin);

				// check for comments
				if (inchar == '/') {
					while (getc(stdin) != '\n') { }
					newline = 1;
				} else if (inchar == '*') {
					newline = 1;
					endcomment = 0;
					while (endcomment == 0) {
						inchar = getc(stdin);
						if (inchar == '*') {
							if (getc(stdin) == '/') endcomment = 1;
						}
					}
				} else {
					// it wasn't a comment (i.e. not '/' or '*')
					// but was a divided-by
					sprintf(outbptr++, "%c", '/');
					ungetc(inchar, stdin);
				}
				break;

			default:
				newline = 0;
				sprintf(outbptr++, "%c", inchar);
		}
	} while (inchar != -1);

	outbptr -= 4;
	sprintf(--outbptr,"%c", '\0'); // back off from the last bogus char

	printf("-------------- C# formatted rtcmix score start --------------\n");
	printf("String score = \"%s;", outbuf);
	printf("\n-------------- C# formatted rtcmix score end --------------\n");
	fflush(stdout);
	getc(stdin);
}
